#include <stdio.h>

int main(void) {

float peso = 74;
float altura = 1.63;

float IMC = peso/(altura*altura);
  
  printf("Seu IMC é: %.1f\n",IMC);


  
  return 0;
}