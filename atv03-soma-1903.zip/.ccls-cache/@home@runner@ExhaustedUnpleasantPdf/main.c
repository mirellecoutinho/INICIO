#include <stdio.h>

int main(void) {
//definir as variáveis A,B e soma.

float A;
float B;
float soma;

printf("DIGITE O PRIMEIRO NÚMERO: \n");

scanf("%F",&A);

printf("DIGITE O SEGUNDO NÚMERO: \n");

scanf("%f",&B);

soma = A+B;

printf("A SOMA DOS DOIS NÚMEROS É: %.2f",soma);


  return 0;
}